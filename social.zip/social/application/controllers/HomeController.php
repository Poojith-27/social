
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class HomeController extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if (!isset($_SESSION['username'])) {
			redirect(base_url());
		}
	}


	public function index()
	{

		if (isset($_FILES['post'])) {
				$file_name = $this->do_upload();
				$data = array(
					"email" => $this->session->username,
					"picture" => $file_name
				);
				$this->db->insert("post_pic",$data);
				redirect("");
		}
		if (isset($_POST['post_matter'])) {
			$data = array(
				"email" => $this->session->username,
				"matter" => $this->input->post("matter")
			);
			$this->db->insert("post_matter",$data);
			redirect("");
		}
		$post_pic = $this->db->get("post_pic")->result();
		$post_matter = $this->db->get("post_matter")->result();
		$data['post_pic'] = $post_pic;
		$data['post_matter'] = $post_matter;
		$this->load->view('home',$data);
	}


	public function do_upload()
	{
		$config['upload_path']          = './assets/uploads/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 10000;
		$config['max_width']            = 10240;
		$config['max_height']           = 7680;

		$this->load->library('upload', $config);

		if ( ! $this->upload->do_upload('post'))
		{
			$error = array('error' => $this->upload->display_errors());

		$this->session->set_flashdata("error",$error);
		print_r($error);
			die();
		}
		else
		{
			$data = array('upload_data' => $this->upload->data());
			$file_name = 	$data["upload_data"]['file_name'];
			return $file_name;
			redirect(base_url(""));

		}
	}

}

?>
