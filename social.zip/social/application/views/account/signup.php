<?php $this->load->view("layout/header") ?>
<section>

  <div class="container">
    <?php if (isset($_SESSION['success'])): ?>
      <div class="alert alert-success">
        <?php echo $this->session->flashdata('success'); ?>
      </div>
    <?php endif; ?>
  </div>
  <div class="container">
    <?php if (isset($_SESSION['error'])): ?>
      <div class="alert alert-danger">
        <?php echo $this->session->flashdata('error'); ?>
      </div>
    <?php endif; ?>
  </div>

  <div class="container pt-2">

    <div class="col-md-4 card p-5 center">
      <h4>Sign Up</h4>
      <hr>
      <form action="" method="post">
        <div class="form-group">
          <label for="">Name</label>
          <input type="text" name="name" id="" class="form-control rounded-0" placeholder="Name" />
          <span class="text-danger"><?php echo form_error('name'); ?></span>
        </div>
        <div class="form-group">
          <label for="">Password</label>
          <input type="password" name="password" id="" class="form-control rounded-0" placeholder="Password"  />
          <span class="text-danger"><?php echo form_error('password'); ?></span>
        </div>
        <div class="form-group">
          <label for="">Confirm Password</label>
          <input type="password" name="confirm" id="" class="form-control rounded-0" placeholder="Confirm Password"  />
          <span class="text-danger"><?php echo form_error('confirm'); ?></span>
        </div>
        <div class="form-group">
          <label for="">Email</label>
          <input type="text" name="email" id="" class="form-control rounded-0" placeholder="Email" />
          <span class="text-danger"><?php echo form_error('email'); ?></span>
        </div>
        <div class="form-group">
          <label for="">Phone</label>
          <input type="text" name="phone" id="" class="form-control rounded-0" placeholder="Phone" />
          <span class="text-danger"><?php echo form_error('phone'); ?></span>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary rounded-0" name="button">Post</button>
        </div>
      </form>
    </div>
  </div>
</section>

<?php $this->load->view("layout/footer") ?>
